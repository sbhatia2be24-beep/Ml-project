import numpy as np
import pandas as pd

RANDOM_SEED = 42
N_RECORDS = 2000


def generate_dataset(n_records=N_RECORDS, random_seed=RANDOM_SEED):
    rng = np.random.default_rng(random_seed)

    study_hours = np.clip(rng.normal(6.0, 2.0, n_records), 1.0, 12.0)
    sleep_hours = np.clip(rng.normal(7.0, 1.2, n_records), 4.0, 10.0)
    screen_time = np.clip(rng.normal(6.0, 2.0, n_records), 1.0, 12.0)
    assignment_workload = np.clip(rng.normal(5.5, 2.1, n_records), 1.0, 10.0)
    physical_activity = np.clip(rng.normal(4.0, 2.2, n_records), 0.0, 10.0)
    attendance = np.clip(rng.normal(82, 10, n_records), 50, 100)
    academic_pressure = np.clip(rng.normal(6.0, 2.0, n_records), 1.0, 10.0)
    social_interaction = np.clip(rng.normal(5.0, 2.0, n_records), 0.0, 10.0)
    upcoming_examinations = rng.binomial(1, 0.48, n_records)
    study_breaks = np.clip(rng.normal(3.5, 1.8, n_records), 0.0, 8.0)

    # Mild realistic relationships between lifestyle variables.
    study_hours = np.clip(study_hours + 0.10 * academic_pressure + 0.35 * upcoming_examinations, 1, 12)
    screen_time = np.clip(screen_time + 0.18 * study_hours, 1, 12)
    sleep_hours = np.clip(sleep_hours - 0.08 * study_hours - 0.12 * academic_pressure, 4, 10)
    assignment_workload = np.clip(assignment_workload + 0.15 * academic_pressure, 1, 10)
    physical_activity = np.clip(physical_activity - 0.10 * study_hours, 0, 10)

    # A noisy latent score. This creates overlap between classes rather than a deterministic rule.
    score = (
        0.95 * study_hours
        + 0.90 * assignment_workload
        + 0.85 * academic_pressure
        + 0.70 * screen_time
        + 1.15 * upcoming_examinations
        - 1.35 * sleep_hours
        - 0.55 * physical_activity
        - 0.035 * attendance
        - 0.38 * social_interaction
        - 0.45 * study_breaks
        + 0.16 * (study_hours * academic_pressure)
        - 0.10 * (sleep_hours * study_breaks)
        + rng.normal(0, 3.0, n_records)
    )

    # Use quantiles so the dataset has a useful amount of each class.
    low_cut, high_cut = np.quantile(score, [0.34, 0.68])
    burnout_risk = np.where(score <= low_cut, "Low", np.where(score <= high_cut, "Moderate", "High"))

    data = pd.DataFrame({
        "daily_study_hours": np.round(study_hours, 2),
        "average_sleep_hours": np.round(sleep_hours, 2),
        "daily_screen_time_hours": np.round(screen_time, 2),
        "assignment_workload": np.round(assignment_workload, 2),
        "physical_activity_hours": np.round(physical_activity, 2),
        "attendance_percentage": np.round(attendance, 2),
        "academic_pressure": np.round(academic_pressure, 2),
        "social_interaction": np.round(social_interaction, 2),
        "upcoming_examinations": upcoming_examinations,
        "study_breaks_per_day": np.round(study_breaks, 2),
        "burnout_risk": burnout_risk,
    })

    # Add a small, reproducible amount of missing data for the cleaning stage.
    for column in data.columns[:-1]:
        missing_count = max(1, int(0.01 * n_records))
        missing_indices = rng.choice(n_records, missing_count, replace=False)
        data.loc[missing_indices, column] = np.nan

    return data


if __name__ == "__main__":
    dataset = generate_dataset()
    dataset.to_csv("dataset.csv", index=False)
    print(f"Saved dataset.csv with shape {dataset.shape}")
    print(dataset["burnout_risk"].value_counts())
