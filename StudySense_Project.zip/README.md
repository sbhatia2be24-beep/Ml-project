# StudySense – Student Burnout Risk Prediction and Lifestyle Analyzer

**Student:** Sumedh Bhatia  
**Roll No.:** 1024030054  
**Batch:** 3C12

## 1. Project idea
StudySense is a simple machine-learning web application that estimates a student's academic burnout-risk category as **Low, Moderate, or High** from study habits, lifestyle habits, and academic workload.

It is an **educational wellness tool, not a medical diagnostic system**. The project is deliberately simple enough to explain in an undergraduate viva.

## 2. Why these input parameters?
| Input | Why it is included |
|---|---|
| Daily study hours | Represents academic time demand. |
| Average sleep duration | Represents recovery and rest. |
| Daily screen time | Represents digital load and possible distraction. |
| Assignment workload | Represents immediate academic workload. |
| Physical activity | Represents lifestyle balance. |
| Attendance percentage | Represents regular academic participation. |
| Academic pressure | Represents perceived academic intensity. |
| Social interaction | Represents balance outside academics. |
| Upcoming examinations | Captures short-term exam pressure. |
| Study breaks per day | Represents how study time is distributed. |

## 3. Dataset
The supplied `dataset.csv` contains **2,000 synthetic student records**. It was generated using `generate_dataset.py` with random seed **42**.

The synthetic generator uses realistic ranges, mild relationships between variables, a noisy latent burnout score, and quantile-based class boundaries. About 1% missing values are intentionally inserted into input columns so that missing-value handling can be demonstrated. The target is created from the latent score and is not copied from any single input feature.

Because the data are synthetic, the measured accuracy must **not** be interpreted as clinical or real-world validation.

## 4. Machine-learning workflow
1. Load CSV with Pandas.
2. Separate 10 input features and the `burnout_risk` target.
3. Use a stratified 80:20 train-test split.
4. Handle missing values using median imputation inside the pipeline.
5. Scale features for Logistic Regression; tree models use imputation without scaling.
6. Tune three models with 5-fold stratified cross-validation:
   - Logistic Regression
   - Decision Tree
   - Random Forest
7. Compare accuracy, macro precision, macro recall, macro F1 and cross-validation macro F1.
8. Select the model with the strongest held-out macro F1, using CV F1 as a stability check.
9. Save the selected pipeline with Joblib.
10. Use the saved pipeline for real-time Streamlit prediction.

## 5. Actual experiment
The current run selected **Logistic Regression**.

| Model | Accuracy | Precision | Recall | F1 | CV F1 mean |
|---|---:|---:|---:|---:|---:|
| Logistic Regression | 0.775 | 0.776 | 0.777 | **0.775** | 0.770 |
| Decision Tree | 0.660 | 0.671 | 0.662 | 0.663 | 0.621 |
| Random Forest | 0.735 | 0.735 | 0.737 | 0.736 | 0.720 |

Best Logistic Regression setting: `C=0.1`.

Top permutation-importance features on the held-out test set were daily study hours, academic pressure, study breaks, assignment workload and sleep duration. These are associations in this synthetic experiment, not proof of causation.

## 6. Folder structure
```text
StudySense/
├── app.py
├── train_model.py
├── generate_dataset.py
├── dataset.csv
├── requirements.txt
├── README.md
├── VIVA_GUIDE.md
├── PROJECT_REPORT.md
├── PROJECT_PRESENTATION.pptx
├── .gitignore
└── models/
    ├── studysense_model.joblib
    └── metadata.json
```

## 7. Installation – Windows
Open Command Prompt/PowerShell in the project folder:

```powershell
py -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
python train_model.py
streamlit run app.py
```

## 8. Installation – macOS/Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python train_model.py
streamlit run app.py
```

The app normally opens at `http://localhost:8501`.

## 9. Quick viva demo
1. Open **Burnout Risk Predictor**.
2. Click **Load Sample Student**.
3. Click **Predict burnout risk**.
4. Show the risk category, probability chart and gauge.
5. Change sleep/study/screen-time/activity values in **What-If Simulator**.
6. Show how the model output changes.
7. Open **Dataset Analysis** and explain distributions/heatmap.
8. Open **Model Performance** and explain why Logistic Regression was selected.

## 10. Limitations
- The dataset is synthetic rather than collected from real students.
- The target is an educational label generated from a noisy simulated process.
- The model cannot diagnose burnout or any medical condition.
- Correlation/feature importance does not establish causation.
- A larger real-world, ethically collected and validated dataset would be needed for a serious deployment.

## 11. Reproducibility
The random seed is fixed at 42 in both dataset generation and model training. Re-running `generate_dataset.py` followed by `train_model.py` recreates the experimental pipeline.
