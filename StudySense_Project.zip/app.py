from pathlib import Path
import json

import joblib
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "dataset.csv"
MODEL_PATH = BASE_DIR / "models" / "studysense_model.joblib"
METADATA_PATH = BASE_DIR / "models" / "metadata.json"

st.set_page_config(
    page_title="StudySense | Burnout Risk Analyzer",
    page_icon="📚",
    layout="wide",
    initial_sidebar_state="expanded",
)

with open(METADATA_PATH, "r", encoding="utf-8") as file:
    metadata = json.load(file)

model = joblib.load(MODEL_PATH)
data = pd.read_csv(DATA_PATH)
FEATURES = metadata["feature_columns"]
CLASS_ORDER = metadata["class_order"]
SELECTED_MODEL = metadata["selected_model"]

LABELS = {
    "daily_study_hours": "Daily study hours",
    "average_sleep_hours": "Average sleep duration",
    "daily_screen_time_hours": "Daily screen time",
    "assignment_workload": "Assignment workload",
    "physical_activity_hours": "Physical activity",
    "attendance_percentage": "Attendance percentage",
    "academic_pressure": "Academic pressure",
    "social_interaction": "Social interaction",
    "upcoming_examinations": "Upcoming examinations",
    "study_breaks_per_day": "Study breaks per day",
}

DIRECTIONS = {
    "daily_study_hours": 1,
    "average_sleep_hours": -1,
    "daily_screen_time_hours": 1,
    "assignment_workload": 1,
    "physical_activity_hours": -1,
    "attendance_percentage": -1,
    "academic_pressure": 1,
    "social_interaction": -1,
    "upcoming_examinations": 1,
    "study_breaks_per_day": -1,
}

st.markdown(
    """
    <style>
    .stApp { background: #f7f8fc; }
    .block-container { max-width: 1250px; padding-top: 2rem; padding-bottom: 3rem; }
    .hero { padding: 28px 32px; border-radius: 24px; background: linear-gradient(135deg, #182848, #4b6cb7); color: white; margin-bottom: 22px; }
    .hero h1 { margin: 0; font-size: 2.6rem; letter-spacing: -1px; }
    .hero p { margin: 8px 0 0; font-size: 1.05rem; opacity: .9; }
    .card { background: white; padding: 20px; border-radius: 18px; border: 1px solid #e7e9f1; box-shadow: 0 6px 24px rgba(24,40,72,.06); }
    .risk-low { background: #eaf8ef; border: 1px solid #bfe7ca; color: #166534; padding: 18px; border-radius: 18px; font-size: 1.3rem; font-weight: 700; }
    .risk-moderate { background: #fff7e6; border: 1px solid #f1d28b; color: #92400e; padding: 18px; border-radius: 18px; font-size: 1.3rem; font-weight: 700; }
    .risk-high { background: #fff0f0; border: 1px solid #f2b8b8; color: #991b1b; padding: 18px; border-radius: 18px; font-size: 1.3rem; font-weight: 700; }
    .small-note { color: #667085; font-size: .9rem; }
    .metric-card { background: white; border: 1px solid #e7e9f1; border-radius: 16px; padding: 16px; text-align: center; }
    </style>
    """,
    unsafe_allow_html=True,
)


def set_sample_profile():
    sample = {
        "daily_study_hours": 8.0,
        "average_sleep_hours": 5.8,
        "daily_screen_time_hours": 8.0,
        "assignment_workload": 8.0,
        "physical_activity_hours": 1.5,
        "attendance_percentage": 74.0,
        "academic_pressure": 8.0,
        "social_interaction": 3.0,
        "upcoming_examinations": 1,
        "study_breaks_per_day": 1.0,
    }
    for key, value in sample.items():
        st.session_state[key] = value
    st.session_state["sample_loaded"] = True


def predict(input_values):
    input_frame = pd.DataFrame([input_values], columns=FEATURES)
    prediction = model.predict(input_frame)[0]
    probabilities = model.predict_proba(input_frame)[0]
    probability_map = dict(zip(model.classes_, probabilities))
    return prediction, probability_map


def risk_indicator(probability_map, prediction):
    numeric_risk = (
        probability_map.get("Low", 0) * 20
        + probability_map.get("Moderate", 0) * 55
        + probability_map.get("High", 0) * 90
    )
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=numeric_risk,
        number={"suffix": "/ 100"},
        title={"text": f"Estimated risk: {prediction}"},
        gauge={
            "axis": {"range": [0, 100]},
            "bar": {"thickness": 0.25},
            "steps": [
                {"range": [0, 40], "name": "Low"},
                {"range": [40, 70], "name": "Moderate"},
                {"range": [70, 100], "name": "High"},
            ],
        },
    ))
    fig.update_layout(height=300, margin=dict(l=20, r=20, t=60, b=20))
    return fig


def recommendations(values, prediction):
    suggestions = []
    if values["average_sleep_hours"] < 7:
        suggestions.append("Aim for a more regular sleep schedule and protect a realistic 7–9 hour sleep window.")
    if values["daily_study_hours"] > 8:
        suggestions.append("Break long study sessions into smaller blocks instead of extending study time continuously.")
    if values["daily_screen_time_hours"] > 7:
        suggestions.append("Reduce non-essential screen time and keep short screen-free breaks between study blocks.")
    if values["physical_activity_hours"] < 3:
        suggestions.append("Add light physical activity such as walking, stretching, or a short workout during the week.")
    if values["study_breaks_per_day"] < 3:
        suggestions.append("Schedule a few short study breaks to make long sessions more sustainable.")
    if values["academic_pressure"] >= 7:
        suggestions.append("Use a simple weekly priority list and divide large assignments into smaller milestones.")
    if values["social_interaction"] < 3:
        suggestions.append("Keep some healthy social contact in your routine rather than studying continuously alone.")
    if values["attendance_percentage"] < 75:
        suggestions.append("Review missed classes and plan catch-up time before workload accumulates further.")
    if not suggestions:
        suggestions.append("Your current inputs look relatively balanced. Keep monitoring sleep, workload, breaks, and activity.")
    return suggestions[:5]


def top_factors(values):
    importance = {item["feature"]: item["importance"] for item in metadata["feature_importance"]}
    median_values = data[FEATURES].median(numeric_only=True)
    scored = []
    for feature in FEATURES:
        value = values[feature]
        median = median_values[feature]
        if feature == "upcoming_examinations":
            deviation = 1 if value == 1 else 0
        else:
            deviation = abs(value - median) / (data[feature].std() + 1e-9)
        scored.append((feature, importance.get(feature, 0) * deviation))
    return sorted(scored, key=lambda x: x[1], reverse=True)[:4]


# Sidebar navigation
st.sidebar.markdown("## 📚 StudySense")
st.sidebar.caption("Educational burnout-risk estimation & lifestyle analysis")
page = st.sidebar.radio(
    "Navigate",
    ["Overview", "Burnout Risk Predictor", "Dataset Analysis", "Model Performance", "Personalized Recommendations", "About the Project"],
)
st.sidebar.divider()
st.sidebar.write(f"**Selected model:** {SELECTED_MODEL}")
st.sidebar.write("**Dataset:** 2,000 synthetic student records")
st.sidebar.caption("Not a medical diagnostic tool.")

st.markdown(
    '<div class="hero"><h1>StudySense</h1><p>Student Burnout Risk Prediction and Lifestyle Analyzer — a simple, explainable ML project for educational use.</p></div>',
    unsafe_allow_html=True,
)

if page == "Overview":
    c1, c2, c3, c4 = st.columns(4)
    for col, value, label in [
        (c1, "2,000", "student records"),
        (c2, "10", "input features"),
        (c3, "3", "ML algorithms"),
        (c4, "3", "risk classes"),
    ]:
        with col:
            st.markdown(f'<div class="metric-card"><h2>{value}</h2><span>{label}</span></div>', unsafe_allow_html=True)

    st.subheader("What does StudySense do?")
    left, right = st.columns([1.15, 1])
    with left:
        st.markdown(
            """
            **StudySense** combines academic workload and lifestyle habits to estimate a student's burnout-risk category as **Low, Moderate, or High**.

            It is intentionally simple: a student enters everyday information, the trained model estimates the class probabilities, and the dashboard gives practical non-medical suggestions.

            The project is designed so every step can be explained in a college viva: dataset generation, cleaning, preprocessing, model comparison, evaluation, prediction, and what-if analysis.
            """
        )
    with right:
        class_counts = data["burnout_risk"].value_counts().reindex(CLASS_ORDER)
        fig = px.bar(x=class_counts.index, y=class_counts.values, labels={"x": "Risk category", "y": "Students"}, title="Dataset class distribution")
        fig.update_layout(height=330)
        st.plotly_chart(fig, use_container_width=True)

    st.info("Important: the dataset is synthetic and the output is an educational risk estimate, not a diagnosis or proof of causation.")

elif page == "Burnout Risk Predictor":
    st.subheader("Burnout Risk Predictor")
    st.write("Enter a student's academic and lifestyle information. Values are intentionally kept easy to understand and explain.")

    if st.button("🎓 Load Sample Student", use_container_width=True):
        set_sample_profile()
        st.rerun()

    with st.form("prediction_form"):
        col1, col2, col3 = st.columns(3)
        with col1:
            daily_study_hours = st.slider("Daily study hours", 1.0, 12.0, float(st.session_state.get("daily_study_hours", 6.0)), 0.5, key="daily_study_hours")
            average_sleep_hours = st.slider("Average sleep duration (hours)", 4.0, 10.0, float(st.session_state.get("average_sleep_hours", 7.0)), 0.1, key="average_sleep_hours")
            daily_screen_time_hours = st.slider("Daily screen time (hours)", 1.0, 12.0, float(st.session_state.get("daily_screen_time_hours", 6.0)), 0.5, key="daily_screen_time_hours")
            assignment_workload = st.slider("Assignment workload (1–10)", 1.0, 10.0, float(st.session_state.get("assignment_workload", 5.5)), 0.5, key="assignment_workload")
        with col2:
            physical_activity_hours = st.slider("Physical activity (hours/day)", 0.0, 10.0, float(st.session_state.get("physical_activity_hours", 4.0)), 0.5, key="physical_activity_hours")
            attendance_percentage = st.slider("Attendance (%)", 50.0, 100.0, float(st.session_state.get("attendance_percentage", 82.0)), 1.0, key="attendance_percentage")
            academic_pressure = st.slider("Academic pressure (1–10)", 1.0, 10.0, float(st.session_state.get("academic_pressure", 6.0)), 0.5, key="academic_pressure")
        with col3:
            social_interaction = st.slider("Social interaction (0–10)", 0.0, 10.0, float(st.session_state.get("social_interaction", 5.0)), 0.5, key="social_interaction")
            upcoming_examinations = st.selectbox("Upcoming examinations", [0, 1], index=int(st.session_state.get("upcoming_examinations", 0)), format_func=lambda x: "Yes" if x else "No", key="upcoming_examinations")
            study_breaks_per_day = st.slider("Study breaks per day", 0.0, 8.0, float(st.session_state.get("study_breaks_per_day", 3.5)), 0.5, key="study_breaks_per_day")
        submitted = st.form_submit_button("Predict burnout risk", use_container_width=True)

    if submitted:
        input_values = {
            "daily_study_hours": daily_study_hours,
            "average_sleep_hours": average_sleep_hours,
            "daily_screen_time_hours": daily_screen_time_hours,
            "assignment_workload": assignment_workload,
            "physical_activity_hours": physical_activity_hours,
            "attendance_percentage": attendance_percentage,
            "academic_pressure": academic_pressure,
            "social_interaction": social_interaction,
            "upcoming_examinations": upcoming_examinations,
            "study_breaks_per_day": study_breaks_per_day,
        }
        prediction, probability_map = predict(input_values)
        st.session_state["last_input"] = input_values
        st.session_state["last_prediction"] = prediction
        st.session_state["last_probabilities"] = probability_map

    if "last_prediction" in st.session_state:
        prediction = st.session_state["last_prediction"]
        probability_map = st.session_state["last_probabilities"]
        input_values = st.session_state["last_input"]
        risk_class = prediction.lower()
        st.markdown(f'<div class="risk-{risk_class}">Predicted burnout risk: {prediction}</div>', unsafe_allow_html=True)
        a, b = st.columns([1, 1])
        with a:
            st.plotly_chart(risk_indicator(probability_map, prediction), use_container_width=True)
        with b:
            probability_df = pd.DataFrame({"Risk": CLASS_ORDER, "Probability": [probability_map.get(c, 0) for c in CLASS_ORDER]})
            fig = px.bar(probability_df, x="Risk", y="Probability", range_y=[0, 1], text_auto=".1%", title="Model-estimated class probabilities")
            fig.update_layout(height=300)
            st.plotly_chart(fig, use_container_width=True)

        st.subheader("Major factors associated with this prediction")
        factor_cols = st.columns(4)
        for col, (feature, score) in zip(factor_cols, top_factors(input_values)):
            with col:
                st.markdown(f"**{LABELS[feature]}**")
                st.caption(f"Relative influence score: {score:.2f}")
                if feature != "upcoming_examinations":
                    direction = "higher" if (input_values[feature] > data[feature].median()) == (DIRECTIONS[feature] == 1) else "lower"
                    st.write(f"Current value: **{input_values[feature]:.1f}** ({direction} risk-associated range)")
                else:
                    st.write("Exam period: **Yes**" if input_values[feature] else "Exam period: **No**")

        st.subheader("What-If Simulator")
        st.caption("Change a few variables and compare the model output. A changed prediction is not evidence that the change causes a real-world outcome.")
        w1, w2, w3, w4 = st.columns(4)
        with w1:
            what_if_sleep = st.slider("What-if sleep", 4.0, 10.0, float(input_values["average_sleep_hours"]), 0.1, key="what_if_sleep")
        with w2:
            what_if_study = st.slider("What-if study hours", 1.0, 12.0, float(input_values["daily_study_hours"]), 0.5, key="what_if_study")
        with w3:
            what_if_screen = st.slider("What-if screen time", 1.0, 12.0, float(input_values["daily_screen_time_hours"]), 0.5, key="what_if_screen")
        with w4:
            what_if_activity = st.slider("What-if activity", 0.0, 10.0, float(input_values["physical_activity_hours"]), 0.5, key="what_if_activity")

        what_if_values = input_values.copy()
        what_if_values.update({
            "average_sleep_hours": what_if_sleep,
            "daily_study_hours": what_if_study,
            "daily_screen_time_hours": what_if_screen,
            "physical_activity_hours": what_if_activity,
        })
        what_if_prediction, what_if_probabilities = predict(what_if_values)
        compare_df = pd.DataFrame({
            "Scenario": ["Original", "What-If"],
            "Risk": [prediction, what_if_prediction],
            "High-risk probability": [probability_map.get("High", 0), what_if_probabilities.get("High", 0)],
        })
        st.dataframe(compare_df, use_container_width=True, hide_index=True)

elif page == "Dataset Analysis":
    st.subheader("Dataset Analysis")
    c1, c2, c3 = st.columns(3)
    c1.metric("Rows", f"{len(data):,}")
    c2.metric("Features", len(FEATURES))
    c3.metric("Missing values", int(data[FEATURES].isna().sum().sum()))

    selected_feature = st.selectbox("Feature distribution", FEATURES, format_func=lambda x: LABELS[x])
    fig = px.histogram(data, x=selected_feature, color="burnout_risk", barmode="overlay", marginal="box", title=f"Distribution of {LABELS[selected_feature]}")
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Correlation heatmap")
    corr = data[FEATURES + ["burnout_risk"]].copy()
    corr["burnout_risk"] = corr["burnout_risk"].map({"Low": 0, "Moderate": 1, "High": 2})
    fig = px.imshow(corr.corr(numeric_only=True), text_auto=".2f", aspect="auto", title="Feature correlation matrix")
    st.plotly_chart(fig, use_container_width=True)

    c1, c2 = st.columns(2)
    with c1:
        box = px.box(data, x="burnout_risk", y="average_sleep_hours", category_orders={"burnout_risk": CLASS_ORDER}, title="Sleep versus burnout risk")
        st.plotly_chart(box, use_container_width=True)
    with c2:
        scatter = px.scatter(data, x="daily_study_hours", y="academic_pressure", color="burnout_risk", category_orders={"burnout_risk": CLASS_ORDER}, title="Study hours versus academic pressure")
        st.plotly_chart(scatter, use_container_width=True)

    st.subheader("Study hours versus burnout risk")
    box2 = px.box(data, x="burnout_risk", y="daily_study_hours", category_orders={"burnout_risk": CLASS_ORDER}, title="Study hours by risk class")
    st.plotly_chart(box2, use_container_width=True)

elif page == "Model Performance":
    st.subheader("Model Performance")
    results = metadata["model_results"]
    comparison_rows = []
    for name, result in results.items():
        comparison_rows.append({
            "Model": name,
            "Accuracy": result["accuracy"],
            "Precision (macro)": result["precision_macro"],
            "Recall (macro)": result["recall_macro"],
            "F1 (macro)": result["f1_macro"],
            "CV F1 (mean)": result["cv_f1_macro_mean"],
        })
    comparison_df = pd.DataFrame(comparison_rows)
    st.dataframe(comparison_df.style.format({c: "{:.3f}" for c in comparison_df.columns[1:]}), use_container_width=True, hide_index=True)
    fig = px.bar(comparison_df, x="Model", y=["Accuracy", "F1 (macro)", "CV F1 (mean)"], barmode="group", title="Model comparison")
    st.plotly_chart(fig, use_container_width=True)

    st.markdown(f"**Selected model:** {SELECTED_MODEL} — chosen using test-set macro F1, with cross-validation used as a stability check.")

    selected_result = results[SELECTED_MODEL]
    cm = np.array(selected_result["confusion_matrix"])
    cm_fig = px.imshow(cm, text_auto=True, x=CLASS_ORDER, y=CLASS_ORDER, labels={"x": "Predicted", "y": "Actual"}, title=f"Confusion matrix — {SELECTED_MODEL}")
    st.plotly_chart(cm_fig, use_container_width=True)

    importance_df = pd.DataFrame(metadata["feature_importance"])
    importance_df["Feature"] = importance_df["feature"].map(LABELS)
    importance_df = importance_df.sort_values("importance", ascending=True)
    fig = px.bar(importance_df, x="importance", y="Feature", orientation="h", error_x="std", title="Permutation feature importance on held-out test data")
    st.plotly_chart(fig, use_container_width=True)

    st.subheader("Best hyperparameters")
    st.json(selected_result["best_params"])

elif page == "Personalized Recommendations":
    st.subheader("Personalized Recommendations")
    st.write("This page turns the input profile into simple, non-medical lifestyle suggestions.")
    if "last_input" not in st.session_state:
        st.info("Run a prediction on the Burnout Risk Predictor page first.")
    else:
        input_values = st.session_state["last_input"]
        prediction = st.session_state["last_prediction"]
        st.markdown(f"Current estimated category: **{prediction}**")
        for i, suggestion in enumerate(recommendations(input_values, prediction), 1):
            st.markdown(f"**{i}.** {suggestion}")
        st.warning("These are general educational suggestions, not medical advice. If a student is struggling significantly, they should consider speaking with a qualified professional or trusted support person.")

else:
    st.subheader("About the Project")
    st.markdown(
        """
        ### Student details
        **Name:** Sumedh Bhatia  
        **Roll No.:** 1024030054  
        **Batch:** 3C12

        ### Project idea
        StudySense is a compact machine-learning application that demonstrates how academic workload and lifestyle variables can be used to estimate a simple burnout-risk category.

        ### Why these parameters?
        - **Study hours:** represents academic time demand.
        - **Sleep:** captures an important recovery-related habit.
        - **Screen time:** represents additional daily digital load.
        - **Assignment workload:** represents short-term academic workload.
        - **Physical activity:** represents a lifestyle balance factor.
        - **Attendance:** reflects regular academic participation.
        - **Academic pressure:** captures perceived workload intensity.
        - **Social interaction:** represents balance outside academics.
        - **Upcoming examinations:** captures short-term exam pressure.
        - **Study breaks:** represents how study time is distributed.

        ### Academic honesty note
        The dataset is **synthetic**, generated with a fixed random seed and a noisy latent-score process. The project therefore demonstrates the ML workflow rather than claiming that the model has been clinically validated on real students.
        """
    )
