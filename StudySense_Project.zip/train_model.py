import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, precision_recall_fscore_support
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

RANDOM_SEED = 42
DATA_PATH = Path("dataset.csv")
MODEL_DIR = Path("models")
MODEL_DIR.mkdir(exist_ok=True)

FEATURE_COLUMNS = [
    "daily_study_hours",
    "average_sleep_hours",
    "daily_screen_time_hours",
    "assignment_workload",
    "physical_activity_hours",
    "attendance_percentage",
    "academic_pressure",
    "social_interaction",
    "upcoming_examinations",
    "study_breaks_per_day",
]
TARGET_COLUMN = "burnout_risk"
CLASS_ORDER = ["Low", "Moderate", "High"]


def build_models():
    imputer = SimpleImputer(strategy="median")
    scaled_preprocessor = Pipeline([
        ("imputer", imputer),
        ("scaler", StandardScaler()),
    ])
    basic_preprocessor = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
    ])

    return {
        "Logistic Regression": (
            Pipeline([
                ("preprocessor", scaled_preprocessor),
                ("classifier", LogisticRegression(max_iter=2000, random_state=RANDOM_SEED)),
            ]),
            {"classifier__C": [0.1, 1.0, 10.0]},
        ),
        "Decision Tree": (
            Pipeline([
                ("preprocessor", basic_preprocessor),
                ("classifier", DecisionTreeClassifier(random_state=RANDOM_SEED)),
            ]),
            {
                "classifier__max_depth": [3, 5, 7, None],
                "classifier__min_samples_leaf": [1, 5, 10],
            },
        ),
        "Random Forest": (
            Pipeline([
                ("preprocessor", basic_preprocessor),
                ("classifier", RandomForestClassifier(random_state=RANDOM_SEED, n_jobs=-1)),
            ]),
            {
                "classifier__n_estimators": [100, 200],
                "classifier__max_depth": [None, 8, 12],
                "classifier__min_samples_leaf": [1, 3],
            },
        ),
    }


def train_and_evaluate():
    data = pd.read_csv(DATA_PATH)
    X = data[FEATURE_COLUMNS]
    y = data[TARGET_COLUMN]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=RANDOM_SEED
    )

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_SEED)
    model_results = {}
    fitted_models = {}

    for model_name, (pipeline, parameter_grid) in build_models().items():
        grid = GridSearchCV(
            pipeline,
            parameter_grid,
            scoring="f1_macro",
            cv=cv,
            n_jobs=-1,
            refit=True,
        )
        grid.fit(X_train, y_train)
        best_model = grid.best_estimator_
        predictions = best_model.predict(X_test)
        probabilities = best_model.predict_proba(X_test)

        precision, recall, f1, _ = precision_recall_fscore_support(
            y_test, predictions, labels=CLASS_ORDER, average="macro", zero_division=0
        )
        cv_scores = cross_val_score(best_model, X_train, y_train, cv=cv, scoring="f1_macro", n_jobs=-1)

        model_results[model_name] = {
            "accuracy": float(accuracy_score(y_test, predictions)),
            "precision_macro": float(precision),
            "recall_macro": float(recall),
            "f1_macro": float(f1),
            "cv_f1_macro_mean": float(cv_scores.mean()),
            "cv_f1_macro_std": float(cv_scores.std()),
            "best_params": grid.best_params_,
            "confusion_matrix": confusion_matrix(y_test, predictions, labels=CLASS_ORDER).tolist(),
            "classification_report": classification_report(y_test, predictions, labels=CLASS_ORDER, output_dict=True, zero_division=0),
        }
        fitted_models[model_name] = best_model

    selected_name = max(
        model_results,
        key=lambda name: (model_results[name]["f1_macro"], model_results[name]["cv_f1_macro_mean"])
    )
    selected_model = fitted_models[selected_name]

    # Model-agnostic feature importance on the held-out test set.
    perm = permutation_importance(
        selected_model,
        X_test,
        y_test,
        scoring="f1_macro",
        n_repeats=15,
        random_state=RANDOM_SEED,
        n_jobs=-1,
    )
    feature_importance = sorted(
        [
            {"feature": feature, "importance": float(mean), "std": float(std)}
            for feature, mean, std in zip(FEATURE_COLUMNS, perm.importances_mean, perm.importances_std)
        ],
        key=lambda item: item["importance"],
        reverse=True,
    )

    joblib.dump(selected_model, MODEL_DIR / "studysense_model.joblib")
    metadata = {
        "random_seed": RANDOM_SEED,
        "feature_columns": FEATURE_COLUMNS,
        "target_column": TARGET_COLUMN,
        "class_order": CLASS_ORDER,
        "selected_model": selected_name,
        "model_results": model_results,
        "feature_importance": feature_importance,
        "dataset_rows": int(len(data)),
        "train_rows": int(len(X_train)),
        "test_rows": int(len(X_test)),
        "dataset_is_synthetic": True,
        "note": "Synthetic educational dataset generated with a reproducible noisy latent-score process. It is not clinical data and is not suitable for medical diagnosis.",
    }
    with open(MODEL_DIR / "metadata.json", "w", encoding="utf-8") as file:
        json.dump(metadata, file, indent=2)

    print(f"Selected model: {selected_name}")
    for name, result in model_results.items():
        print(name, result["accuracy"], result["precision_macro"], result["recall_macro"], result["f1_macro"], result["cv_f1_macro_mean"])
    print("Top features:")
    for item in feature_importance[:5]:
        print(item)

    return metadata


if __name__ == "__main__":
    train_and_evaluate()
