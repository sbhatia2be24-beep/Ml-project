# StudySense – Student Burnout Risk Prediction and Lifestyle Analyzer

**Student:** Sumedh Bhatia  
**Roll No.:** 1024030054  
**Batch:** 3C12

## Abstract
StudySense is a beginner-friendly machine-learning application for estimating student burnout risk as Low, Moderate or High from academic workload and lifestyle habits. The project uses a reproducible synthetic dataset of 2,000 records and compares Logistic Regression, Decision Tree and Random Forest. The workflow includes data cleaning, missing-value handling, stratified train-test splitting, feature scaling where appropriate, hyperparameter tuning with 5-fold cross-validation, model evaluation and deployment through Streamlit. In the current experiment, Logistic Regression achieved the best held-out macro F1 score of 0.775 and was selected for the final application. The system also provides probabilities, a visual risk indicator, permutation-based feature importance, recommendations and a what-if simulator. The application is an educational demonstration and is not a medical diagnostic tool.

# Chapter 1 – Introduction

## 1.1 Background
Students often balance classes, assignments, examinations, screen use, sleep, physical activity and social life at the same time. A machine-learning project can demonstrate how these variables may be combined into a simple risk-estimation tool.

## 1.2 Problem statement
The problem is to build a compact classification system that maps student academic/lifestyle information to one of three educational risk categories: Low, Moderate or High.

## 1.3 Motivation
The topic was selected because it is relatable, has clear numeric inputs, allows comparison of basic classification algorithms and can be presented through an interactive dashboard.

## 1.4 Scope
The system is designed for learning and demonstration. It is not intended to diagnose burnout, predict medical outcomes or replace professional support.

# Chapter 2 – Literature Survey

## 2.1 Student stress and academic workload
Research on student wellbeing commonly considers workload, sleep, social factors and academic pressure as relevant dimensions of student experience. These ideas motivate the selection of variables in StudySense.

## 2.2 Machine learning for classification
Supervised classification methods are widely used when examples have known labels. Logistic Regression provides a simple probabilistic baseline, Decision Trees provide interpretable rules, and Random Forests combine multiple trees for greater stability.

## 2.3 Research gap
1. Many student-wellbeing discussions are descriptive; StudySense turns multiple everyday factors into a single simple educational classification workflow.
2. A number of ML projects become unnecessarily complex; this project deliberately uses only undergraduate-friendly algorithms and tools.
3. The dashboard combines prediction, model explanation and a what-if demonstration in one small application.

## 2.4 References for background
1. Pedregosa et al., “Scikit-learn: Machine Learning in Python,” *Journal of Machine Learning Research*, 2011.
2. Géron, *Hands-On Machine Learning with Scikit-Learn, Keras & TensorFlow*, O’Reilly.
3. Kuhn & Johnson, *Applied Predictive Modeling*, Springer.
4. Streamlit Documentation, official documentation.
5. Scikit-learn User Guide, official documentation.

# Chapter 3 – Objectives and Methodology

## 3.1 Objectives
- Build a simple three-class burnout-risk classifier.
- Use ten understandable academic/lifestyle parameters.
- Compare three basic classification algorithms.
- Use reproducible preprocessing and evaluation.
- Deploy the selected model in a Streamlit application.
- Provide an interpretable what-if demonstration and recommendations.

## 3.2 Data collection
A suitable public dataset containing all requested features and a compatible target was not selected for this educational version. Therefore, `generate_dataset.py` creates approximately 2,000 synthetic records with NumPy using random seed 42.

The feature ranges are realistic rather than exact measurements of any specific population. A noisy latent score combines the variables and quantile thresholds create the three classes. Around 1% missing values are intentionally inserted into each input column to demonstrate data cleaning.

## 3.3 Data cleaning
The target column is separated from the inputs. Numeric missing values are filled using median imputation inside the ML pipeline. This prevents information from the test set from influencing preprocessing during training.

## 3.4 Parameter selection
The ten parameters were chosen because each is easy to interpret and corresponds to either academic load, recovery, lifestyle balance or short-term academic pressure. No parameter is selected because it guarantees a particular prediction.

## 3.5 Preprocessing
Logistic Regression uses median imputation followed by StandardScaler. Decision Tree and Random Forest use median imputation without scaling. All preprocessing is inside a scikit-learn Pipeline so training and prediction use the same steps.

## 3.6 Train-test split
An 80:20 stratified split is used with random seed 42. Stratification helps preserve the proportions of Low, Moderate and High classes.

## 3.7 Model training and hyperparameter tuning
Three models are trained:

### Logistic Regression
Searches `C = 0.1, 1.0, 10.0`.

### Decision Tree
Searches `max_depth = 3, 5, 7, None` and `min_samples_leaf = 1, 5, 10`.

### Random Forest
Searches `n_estimators = 100, 200`, `max_depth = None, 8, 12` and `min_samples_leaf = 1, 3`.

GridSearchCV uses 5-fold StratifiedKFold and macro F1 as the tuning score. Macro F1 was selected because all three risk categories should receive equal importance.

## 3.8 Model explanation
Permutation importance is calculated on the held-out test set for the selected model. It measures how much test performance changes when a feature is shuffled. The current run ranks daily study hours and academic pressure highest, followed by study breaks, assignment workload and sleep duration.

## 3.9 Application implementation
The Streamlit app contains six sections:
- Overview
- Burnout Risk Predictor
- Dataset Analysis
- Model Performance
- Personalized Recommendations
- About the Project

The predictor accepts sliders/numeric controls, returns a class and probabilities, shows a risk gauge, displays major associated factors and provides recommendations. The what-if simulator changes selected inputs and compares the new prediction with the original one.

# Chapter 4 – Results and Discussion

## 4.1 Experimental results
The final experiment was run with random seed 42.

| Model | Accuracy | Precision | Recall | Macro F1 | 5-fold CV Macro F1 |
|---|---:|---:|---:|---:|---:|
| Logistic Regression | 77.5% | 77.6% | 77.7% | **77.5%** | 77.0% |
| Decision Tree | 66.0% | 67.1% | 66.2% | 66.3% | 62.1% |
| Random Forest | 73.5% | 73.5% | 73.7% | 73.6% | 72.0% |

## 4.2 Confusion matrix – selected model
For Logistic Regression, with rows as actual and columns as predicted in the order Low, Moderate, High:

| Actual \ Predicted | Low | Moderate | High |
|---|---:|---:|---:|
| Low | 110 | 25 | 1 |
| Moderate | 18 | 90 | 28 |
| High | 0 | 18 | 110 |

The model is strongest on Low and High examples and has more overlap in the Moderate class. This is reasonable because Moderate is a middle category and nearby examples can be harder to separate.

## 4.3 Feature importance
Top permutation-importance results were:
1. Daily study hours – 0.201
2. Academic pressure – 0.186
3. Study breaks per day – 0.075
4. Assignment workload – 0.070
5. Average sleep duration – 0.066

These are model associations in synthetic data and should not be interpreted as causal effects.

## 4.4 Why Logistic Regression was selected
Logistic Regression had the highest held-out macro F1 (0.775), higher than Random Forest (0.736) and Decision Tree (0.663). Its CV macro F1 was also the highest (0.770). It is therefore both the best-performing model in this experiment and one of the easiest models to explain in a viva.

## 4.5 App showcase
The Streamlit application provides:
- clean dashboard overview;
- interactive prediction inputs;
- class probability chart;
- risk gauge;
- feature-importance based major factors;
- personalized non-medical recommendations;
- dataset visualizations and correlation heatmap;
- model comparison and confusion matrix;
- what-if simulator;
- sample student button for a quick viva demonstration.

## 4.6 Discussion
The results demonstrate that basic classification algorithms can learn patterns from the simulated dataset. However, the numerical performance is mainly evidence that the workflow is functioning on the generated data. It is not evidence that the model would achieve the same performance on real students.

# Chapter 5 – Conclusion, Limitations and Future Scope

## 5.1 Conclusion
StudySense successfully demonstrates a complete undergraduate ML workflow from data generation and cleaning to model training, evaluation and deployment. The project remains intentionally simple while still including reproducibility, cross-validation, model comparison, explanation and an interactive application.

## 5.2 Limitations
- Synthetic dataset.
- Simulated target rather than a clinically or professionally assessed label.
- No external validation dataset.
- No longitudinal measurements.
- Feature importance does not establish causality.
- Not a diagnostic or treatment system.

## 5.3 Future scope
A future version could use an ethically collected real-world dataset, add external validation, calibration, fairness analysis, longitudinal tracking and expert review. Privacy and informed consent would be essential for any real deployment.

## References
1. Pedregosa, F. et al. (2011). Scikit-learn: Machine Learning in Python. *JMLR*, 12, 2825–2830.
2. Géron, A. *Hands-On Machine Learning with Scikit-Learn, Keras & TensorFlow*. O’Reilly.
3. Kuhn, M. & Johnson, K. *Applied Predictive Modeling*. Springer.
4. Scikit-learn User Guide.
5. Streamlit Documentation.
