# StudySense Viva Guide

**Student:** Sumedh Bhatia | **Roll No.:** 1024030054 | **Batch:** 3C12

## 60-second introduction
“Good morning. My project is **StudySense – Student Burnout Risk Prediction and Lifestyle Analyzer**. The aim is to build a simple machine-learning application that estimates whether a student's burnout risk is Low, Moderate, or High using academic and lifestyle inputs such as study hours, sleep, screen time, assignment workload, physical activity, attendance, academic pressure, social interaction, exams and study breaks. I created a reproducible synthetic dataset of 2,000 records because a suitable public dataset matching all these fields and a simple target was not selected for this project. I compared Logistic Regression, Decision Tree and Random Forest using an 80:20 stratified split and 5-fold cross-validation. Logistic Regression gave the best test macro F1 of 0.775, so it was selected. The trained pipeline is saved with Joblib and used by a Streamlit dashboard. The result is an educational estimate, not a medical diagnosis.”

## 3-minute demonstration script
1. **Overview:** “This page explains the problem and shows the three risk classes.”
2. **Predictor:** “These ten inputs were selected because together they represent academic load, recovery, lifestyle balance and short-term exam pressure.”
3. Click **Load Sample Student**.
4. Click **Predict burnout risk**.
5. Explain: “The model returns a class, class probabilities and a visual risk indicator. Probabilities show the model's confidence distribution, not medical probability.”
6. Show **Major factors** and explain that permutation importance is a model-explanation tool.
7. Show **What-If Simulator:** change sleep or study hours and compare Original vs What-If. Say: “This is a model sensitivity demonstration. A changed prediction does not prove that changing one factor will cause the same change in a real student.”
8. **Dataset Analysis:** show class distribution, feature histogram, heatmap, sleep box plot and study-hour box plot.
9. **Model Performance:** show the comparison table and say Logistic Regression had the strongest macro F1 on the held-out test set.
10. **Recommendations:** show simple lifestyle suggestions based on entered values.
11. End with limitations: “Synthetic data and educational labels mean the project is not clinically validated.”

## Complete ML pipeline
### 1. Data generation
`generate_dataset.py` creates 2,000 records using NumPy with seed 42. Variables are sampled from sensible ranges. Mild relationships are added, such as higher academic pressure slightly increasing study hours and workload.

### 2. Target creation
A noisy latent score combines the inputs using positive and negative contributions. Quantiles split the score into Low, Moderate and High. Noise prevents a perfect deterministic relationship.

### 3. Missing values
Approximately 1% missing values are inserted into each input feature. The training pipeline handles them with median imputation.

### 4. Train-test split
`train_test_split(..., stratify=y, test_size=0.20, random_state=42)` keeps the class proportions similar in train and test data.

### 5. Preprocessing
Logistic Regression uses median imputation + StandardScaler. Decision Tree and Random Forest use median imputation only because tree splits do not require feature scaling.

### 6. Hyperparameter tuning
GridSearchCV with 5-fold StratifiedKFold searches small, understandable parameter grids. The tuning score is macro F1 because all three classes should matter.

### 7. Model comparison
- Logistic Regression: linear decision boundary and easy to explain.
- Decision Tree: rule-like splits and very visual logic.
- Random Forest: many trees combined to reduce instability.

### 8. Final selection
The model with the best held-out macro F1 is selected, with cross-validation used as a stability check. In the current run this was Logistic Regression.

### 9. Saving
`joblib.dump()` saves the complete preprocessing + model pipeline. This prevents training-time preprocessing from being accidentally different at prediction time.

### 10. Deployment
Streamlit loads the saved pipeline and accepts user input. The exact same pipeline performs preprocessing and prediction.

## Important functions/files
- `generate_dataset.py`: creates the synthetic CSV.
- `train_model.py`: loads data, trains/tunes models, evaluates them and saves artifacts.
- `app.py`: Streamlit interface, prediction, charts, recommendations and what-if simulator.
- `dataset.csv`: 2,000-row input dataset.
- `models/studysense_model.joblib`: selected trained pipeline.
- `models/metadata.json`: metrics, confusion matrix, selected model and feature importance.
- `PROJECT_REPORT.md`: five-chapter college report.
- `PROJECT_PRESENTATION.pptx`: presentation for the project viva.

## Algorithms in simple language
### Logistic Regression
It learns a weighted combination of the input features and converts the scores into class probabilities. It is fast, simple and interpretable.

### Decision Tree
It repeatedly asks questions such as “Is study time above a threshold?” and follows branches until it reaches a class. It is easy to visualize but can overfit if it grows too much.

### Random Forest
It trains many decision trees on slightly different samples/features and combines their votes. It is usually more stable than one tree but is less simple to explain than a single tree.

## Core ML concepts
**Overfitting:** model learns training-specific patterns/noise and performs poorly on unseen data.

**Underfitting:** model is too simple and fails to capture useful patterns.

**Feature scaling:** puts numeric features on comparable scale. Important for distance/gradient-based models such as Logistic Regression; generally unnecessary for trees.

**Train-test split:** keeps a portion of data unseen until final evaluation.

**Cross-validation:** repeatedly trains/validates on different folds to estimate stability.

**Precision:** among predicted positives for a class, how many were actually that class.

**Recall:** among actual examples of a class, how many were found.

**F1-score:** harmonic mean of precision and recall.

**Macro F1:** average F1 across classes, giving each class equal importance.

**Confusion matrix:** table showing actual classes versus predicted classes.

**Accuracy:** fraction of all predictions that are correct.

## 40 likely viva questions
1. **What is your project?** StudySense, a simple ML-based educational burnout-risk estimator.
2. **Why did you choose this topic?** It connects ML with a relatable student-life problem and has understandable inputs.
3. **Is it a medical system?** No. It is an educational wellness tool only.
4. **Why synthetic data?** A simple dataset matching all required fields and target was not selected, so a reproducible synthetic dataset was created.
5. **How many records?** 2,000.
6. **How many input features?** 10.
7. **What is the target?** Low, Moderate or High burnout risk.
8. **Why study hours?** It represents academic time demand.
9. **Why sleep?** It represents rest/recovery habits.
10. **Why screen time?** It represents digital load.
11. **Why assignment workload?** It represents immediate academic workload.
12. **Why physical activity?** It represents lifestyle balance.
13. **Why attendance?** It represents academic participation.
14. **Why academic pressure?** It represents perceived academic intensity.
15. **Why social interaction?** It represents non-academic balance.
16. **Why upcoming exams?** Exams create short-term academic pressure.
17. **Why study breaks?** They represent how study time is distributed.
18. **What is target leakage?** Using information that would not legitimately be available when making the prediction.
19. **How did you avoid leakage?** The target is generated separately from a latent score and is not copied from a single input; preprocessing is fit only inside the training pipeline.
20. **Why stratified split?** To preserve class proportions in train and test sets.
21. **Why 80:20?** It gives enough data for learning while keeping a useful unseen test set.
22. **Why imputation?** ML models generally cannot accept NaN values directly.
23. **Why median imputation?** Median is simple and less sensitive to outliers than mean.
24. **Why scale Logistic Regression?** Feature magnitudes can affect optimization and coefficient comparison.
25. **Why not scale trees?** Tree thresholds are based on ordering, so scaling is usually unnecessary.
26. **Why three models?** They provide simple linear, rule-based and ensemble comparisons.
27. **Which model won?** Logistic Regression.
28. **What was its accuracy?** 0.775.
29. **What was its macro F1?** 0.775.
30. **What was its CV macro F1?** About 0.770.
31. **Why macro F1?** It gives equal importance to Low, Moderate and High classes.
32. **What is GridSearchCV?** It tests selected hyperparameter combinations using cross-validation.
33. **What is C in Logistic Regression?** It controls regularization strength; smaller C means stronger regularization.
34. **What is max_depth in a tree?** Maximum number of levels in the tree.
35. **What is n_estimators in Random Forest?** Number of trees in the forest.
36. **What is permutation importance?** It measures how much performance changes when a feature is randomly shuffled.
37. **Does importance prove causation?** No.
38. **Why save the pipeline?** To keep preprocessing and prediction consistent.
39. **What is Streamlit?** A Python framework for quickly building interactive data/ML web apps.
40. **What is the biggest limitation?** The dataset is synthetic and the target is simulated, so real-world validity is not established.

## Future scope
Use an ethically collected real student dataset, external validation, fairness checks, calibration, longitudinal data and stronger privacy controls. If used in a real institution, obtain appropriate consent and expert review.
